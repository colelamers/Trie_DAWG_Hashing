package io.documentnode.epub4j.domain;

public interface ManifestProperties {

  String getName();
}
